package com.example.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.entities.StoreImage;

public interface ImageRepo extends JpaRepository<StoreImage, Long> {
	Optional<StoreImage> findByName(String fileName);

}
