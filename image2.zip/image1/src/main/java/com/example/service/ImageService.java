package com.example.service;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.entities.StoreImage;
import com.example.repo.ImageRepo;
import com.example.util.ImageUtil;



@Service
public class ImageService {
	
	@Autowired
    private ImageRepo imageRepo;
	
	public ImageRepo uploadImage(MultipartFile file) throws IOException {
		StoreImage pImage = new StoreImage();
		pImage.setName(file.getOriginalFilename());
		pImage.setType(file.getContentType());
		pImage.setImageData(ImageUtil.compressImage(file.getBytes()));
		return (ImageRepo) imageRepo.save(pImage);
	}
	
	public byte[] downloadImage(String fileName){
        Optional<StoreImage> imageData = imageRepo.findByName(fileName);
        return ImageUtil.decompressImage(imageData.get().getImageData());
    }
}