package com.inventory.repo;


import org.springframework.data.repository.CrudRepository;

import com.inventory.entities.Books;

public interface BooksRepository extends CrudRepository<Books, Integer>  
{  
}  
